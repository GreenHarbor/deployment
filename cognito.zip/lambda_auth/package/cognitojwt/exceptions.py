

class CognitoJWTException(Exception):
    """Raised when something went wrong in token verification proccess"""


__all__ = [
    'CognitoJWTException'
]
