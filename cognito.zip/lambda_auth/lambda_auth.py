import json
from datetime import datetime
import urllib.request
from jose import jwk, jwt
from jose.utils import base64url_decode
import pytz

region = 'us-east-2'
userpool_id = 'us-east-2_cv8NhC3FK'
app_client_id = '1iafjm3k7sgm1diiio0gr4gvvs'
keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(region, userpool_id)
PREFIX = 'Bearer '
# instead of re-downloading the public keys every time
# we download them only on cold start
# https://aws.amazon.com/blogs/compute/container-reuse-in-lambda/
with urllib.request.urlopen(keys_url) as f:
  response = f.read()
keys = json.loads(response.decode('utf-8'))['keys']

def lambda_handler(event, context):
    auth = event['headers']["authorization"]
    if not auth.startswith(PREFIX):
        return {
                    'statusCode': 400,
                    'body': json.dumps({"error": True, 
                        "message": "Invalid token",
                })}

    token = auth[len(PREFIX):]
    if len(token)==0:
       return {
                    'statusCode': 400,
                    'body': json.dumps({"error": True, 
                        "message": "Token is not present",
                })}
    
    token = str(token)

    # get the kid from the headers prior to verification
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']
    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break
    if key_index == -1:
        return {
        'statusCode': 401,
        'body': json.dumps({
            "success": False, 
            "message": "No public key found in cognito", 
        })
        }
    # construct the public key
    public_key = jwk.construct(keys[key_index])
    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)
    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    # verify the signature
    if not public_key.verify(message.encode("utf8"), decoded_signature):
        return {
        'statusCode': 401,
        'body': json.dumps({
            "success": False, 
            "message": "Signature verification failed", 
        })
        }
    # since we passed the verification, we can now safely
    # use the unverified claims
    try:
        claims = jwt.get_unverified_claims(token)

    except Exception as e: 
        return {
        'statusCode': 500,
        'body': json.dumps({
            "success": False, 
            "message": str(e), 
        })
    }
    
    if ("client_id" in claims and claims['client_id'] != app_client_id) or ("aud" in claims and claims["aud"] != app_client_id):
            return {
            'statusCode': 401,
            'body': json.dumps({
                "success": False, 
                "message": "Token was not issued for this audience", 
            })
            }
    
    # additionally we can verify the token expiration
    exp_time=claims["exp"]
    utc_dt=datetime.utcfromtimestamp(float(exp_time))

    local_tz = pytz.timezone('Singapore') # use your local timezone name here
    local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(local_tz)
    print(local_dt)
    print(datetime.now(tz=local_tz))

    if datetime.now(tz=local_tz)<local_dt:
        return {
            'statusCode': 200,
            'body': json.dumps({
                "success": True, 
                "message": "User is authenticated", 
                "data":{
                "username": claims["cognito:username"],
                "email": claims["email"]
                }
            })
        }
    else:
        return {
            'statusCode': 401,
            'body': json.dumps({
                "success": False, 
                "message": "JWT expired", 
            })
        }
        
# the following is useful to make this script executable in both
# AWS Lambda and any other local environments
if __name__ == '__main__':
    # for testing locally you can enter the JWT ID Token here
    event = {'token': 'eyJraWQiOiJScUlMdUJQQWFhOUdoOW9sTDFDUSs2bG5JaHBORktsMnZVbGRiR1ppYXkwPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIwNzUwZDNjMC1hMzljLTQ3ZTktYmY5Mi03MGY4NWRhOWM2ZWYiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTIuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0yX2N2OE5oQzNGSyIsImNvZ25pdG86dXNlcm5hbWUiOiJ0ZXN0X3VzZXIzIiwib3JpZ2luX2p0aSI6ImQ0YTIyM2IzLTZhMzUtNGY4OC05ZGM5LWU2NzNlM2I5NmRmNCIsImF1ZCI6IjFpYWZqbTNrN3NnbTFkaWlpbzBncjRndnZzIiwiZXZlbnRfaWQiOiJmN2MyZDYzOC04ZDYzLTQ3NWQtODIwOC0zN2IyZjI2MGJkOWQiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTY5NzMzNTAzMiwiZXhwIjoxNjk3MzM4NjMyLCJpYXQiOjE2OTczMzUwMzIsImp0aSI6IjliZTQwMjgyLTZjNjItNGQ0ZS04ZTBhLTEwYzNkNzJjZWNlYiIsImVtYWlsIjoiemR3b25nLjIwMTFAdS5lZHUuc2cifQ.b-d2Fw7q22hkQIt8-7JnVVtCWZTQs9ufQ8bIi-5ScGk-udeb3e-DP8EO6iHlAyItrfr5YUwOnd2qBxqaLChC7NtX7JgCMs1wHRgpf_-Fdbhb_K6d7knN7OApjoc0jqJADwZV9UxKP4oQ4SZnCMuUVyvIjwMo9aRm9mGDXhw5886AHw9afFFP1bZ6jKsvi-L7raLCA4qzzN9tjlkJZAJNOhNlhnfuNjsr3NOUXa65Wll35VFaCCAUz_6HiKKMmxGapivguRtEpXwNqiNY1vvGj1V38MhFbNC923AMf-uqmDcdP-9QvW-7rSb5TDuB6UROndo2hMiSQVQRIOsqZ1l28Q'}
    print(lambda_handler(event, None))